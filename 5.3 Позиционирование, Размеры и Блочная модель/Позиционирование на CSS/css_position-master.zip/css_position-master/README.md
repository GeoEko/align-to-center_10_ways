# Позиционирование на CSS

Как работать с позиционированием на CSS на наглядных примерах. Рассмотрим все свойства максимально подробно.

**Рассмотрим следующие свойства:**

>position: static | relative | absolute | fixed | sticky  
>top  
>bottom  
>left  
>right  
>z-index 

---

[![GitHub](https://img.shields.io/badge/-Мой_GitHub-333?style=for-the-badge&logo=GitHub&logoColor=fff)](https://github.com/morphIsmail)
